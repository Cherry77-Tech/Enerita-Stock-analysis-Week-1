# Stock Market Trend Classification

## Phase 1 (Week I) Deliverables
- ✅ Day 1: Data Loading
- ✅ Day 2: Data Quality Assessment
- ✅ Day 3-4: Exploratory Data Analysis
- ✅ Day 5: Feature Selection & Modeling Dataset

## Structure
- `data/`: Cleaned datasets used in analysis
- `notebooks/`: Jupyter notebooks for each day
- `reports/`: Summary PDFs for submission

## Submission
Fork this repo and submit at: https://github.com/datascience-muhammad/Stock-analysis
